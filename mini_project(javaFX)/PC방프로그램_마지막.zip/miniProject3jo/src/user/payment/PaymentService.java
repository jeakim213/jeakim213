package user.payment;

import javafx.scene.Parent;

public interface PaymentService {
	public void payProc(Parent root);
	
}
