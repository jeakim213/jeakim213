package main;

import javafx.scene.Parent;

public interface LoginService {
	
	public void loginProc(Parent root);
	public void registerOpen();
	public void timeChargeOpen();
	
}
