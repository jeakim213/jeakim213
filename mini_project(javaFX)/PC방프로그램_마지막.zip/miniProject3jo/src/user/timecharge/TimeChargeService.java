package user.timecharge;

import javafx.scene.Parent;

public interface TimeChargeService {
	public void TCIdSearchProc(Parent root);
	public void payOpen(Parent root);
	
}
